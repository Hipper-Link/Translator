es_en = {
    "hola": "hello",
    "como estas": "how are you",
    "adios": "goodbye",
    "gracias": "thank you",
    "buenos dias": "good morning"
}

en_es = {v: k for k, v in es_en.items()}

frase = input("Escribe una frase: ").lower()


espanol = sum(1 for palabra in frase.split() if palabra in es_en)
ingles = sum(1 for palabra in frase.split() if palabra in en_es)

if ingles > espanol:
    diccionario = en_es
else:
    diccionario = es_en

for clave in diccionario:
    if " " in clave and clave in frase:
        frase = frase.replace(clave, diccionario[clave])

palabras = frase.split()
traduccion = []

for palabra in palabras:
    traduccion.append(diccionario.get(palabra, palabra))

print("Traducción:", " ".join(traduccion))