es_en = {
    "hola": "hello",
    "adios": "goodbye",
    "gracias": "thank you",
    "por favor": "please",
    "perro": "dog",
    "gato": "cat",
    "como": "how",
    "estas": "are you",

}

en_es = {v: k for k, v in es_en.items()}


opcion = input("¿Español a inglés (1) o inglés to spanish (2)? ")

frase = input("Escribe la frase: ").lower()


if opcion == "1":
    diccionario = es_en
elif opcion == "2":
    diccionario = en_es
else:
    print("Opción inválida xd")
    diccionario = {}

for clave in diccionario:
    if " " in clave and clave in frase:
        frase = frase.replace(clave, diccionario[clave])

palabras = frase.split()
traduccion = []

for palabra in palabras:
    if palabra in diccionario:
        traduccion.append(diccionario[palabra])
    else:
        traduccion.append(palabra)  

print("Traducción:", " ".join(traduccion))